package fr.aston.jdr.services;

import fr.aston.jdr.modele.Combat;
import fr.aston.jdr.modele.Heros;
import fr.aston.jdr.modele.Monstre;
import fr.aston.jdr.modele.Partie;
import fr.aston.jdr.modele.Personnage;

public class CombatService {

	private Combat combat;

	public CombatService() {

	}

	public Combat getCombat() {
		return combat;
	}

	public void setCombat(Combat combat) {
		this.combat = combat;
	}

	public void setTour(Partie partie) {
		if (partie.getHeros().isEmpty() || partie.getMonstre().isEmpty()) {
			combat.setTourN(0);
		} else {
			combat.setTourN(combat.getTourN() + 1);
		}
	}

	public Partie Combattre(Partie partie, Combat combat) {

		String s = "\n ---------" + combat.getTourN() + " ème manche-------\n";
		System.out.println(s);

		PersonnageService personnageService = new PersonnageService();
		HerosService herosService = new HerosService();

		int rdm = (int) Math.floor(Math.random() * 100);
		if (rdm >= 50) {

			for (Personnage personnage : partie.getHeros()) {
				Heros heros = (Heros) personnage;

				if (heros.getClasse().equals("Soigneur")) {
					int rdmHeal = (int) Math.floor(Math.random() * 100);
					if (rdmHeal >= 20) {
						Personnage heale = herosService.Heal(partie.getHeros());
						if (heale.getHp() < heale.getMaxHp()) {
							heale.setHp(heale.getMaxHp());
							System.out.println(heros.getNom() + " soigne " + heale.getNom());
						} else {
							personnageService.Cibler(partie.getMonstre(), heros);
							RamasserMorts(partie);
						}
					} else {
						personnageService.Cibler(partie.getMonstre(), heros);
						RamasserMorts(partie);
					}
				} else {
					personnageService.Cibler(partie.getMonstre(), heros);
					RamasserMorts(partie);
				}
			}

			for (Personnage personnage : partie.getMonstre()) {
				Monstre monstre = (Monstre) personnage;
				personnageService.Cibler(partie.getHeros(), monstre);
				RamasserMorts(partie);
			}

		} else {

			for (Personnage personnage : partie.getMonstre()) {
				Monstre monstre = (Monstre) personnage;
				personnageService.Cibler(partie.getHeros(), monstre);
				RamasserMorts(partie);
			}

			for (Personnage personnage : partie.getHeros()) {
				Heros heros = (Heros) personnage;

				if (heros.getClasse().equals("Soigneur")) {
					int rdmHeal = (int) Math.floor(Math.random() * 100);
					if (rdmHeal >= 20) {
						Personnage heale = herosService.Heal(partie.getHeros());
						if (heale.getHp() < heale.getMaxHp()) {
							heale.setHp(heale.getMaxHp());
							System.out.println(heros.getNom() + " soigne " + heale.getNom());
						} else {
							personnageService.Cibler(partie.getMonstre(), heros);
							RamasserMorts(partie);
						}
					} else {
						personnageService.Cibler(partie.getMonstre(), heros);
						RamasserMorts(partie);
					}
				} else {
					personnageService.Cibler(partie.getMonstre(), heros);
					RamasserMorts(partie);
				}
			}
		}
		return partie;

	}

	public void RamasserMorts(Partie p) {
		for (int i = p.getHeros().size() - 1; i >= 0; i--) {
			if (p.getHeros().get(i).getHp() <= 0) {
				System.out.println(p.getHeros().get(i).getNom() + " est mort !");
				p.getHeros().remove(i);
			}
		}
		for (int i = p.getMonstre().size() - 1; i >= 0; i--) {
			if (p.getMonstre().get(i).getHp() <= 0) {
				System.out.println(p.getMonstre().get(i).getNom() + " est mort !");
				p.getMonstre().remove(i);

			}
		}
	}

}
