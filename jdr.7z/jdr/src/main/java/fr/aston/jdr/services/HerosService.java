package fr.aston.jdr.services;

import java.util.List;
import java.util.Scanner;

import fr.aston.jdr.modele.Arme;
import fr.aston.jdr.modele.Heros;
import fr.aston.jdr.modele.Personnage;

public class HerosService {

	Scanner sc = new Scanner(System.in);

	private String nomClasse;

	public Personnage defClasse(int choixClasse) {
		
		Heros heros = new Heros();
		
		switch (choixClasse) {

		case 1:
			nomClasse = "Archer";
			heros.setClasse(nomClasse);
			heros.setMaxHp(100);
			heros.setHp(100);
			break;
			
		case 2:
			nomClasse = "Guerrier";
			heros.setClasse(nomClasse);
			heros.setMaxHp(80);
			heros.setHp(80);
			break;
			
		case 3:
			nomClasse = "Soigneur";
			heros.setClasse(nomClasse);
			heros.setMaxHp(70);
			heros.setHp(70);
			break;
			
		case 4:
			nomClasse = "Assassin";
			heros.setClasse(nomClasse);
			heros.setMaxHp(40);
			heros.setHp(40);
			break;

		default:
			break;
		}
		
		return heros;

	}

	public Personnage Heal(List<Personnage> herosListe) {
		int faible=0;
		int hpf=100;
		for (int i = 0; i < herosListe.size(); i++) {
			if(herosListe.get(i).getHp()
					<hpf&&herosListe.get(i).getHp()
					<herosListe.get(i).getMaxHp()) {
				
				hpf=herosListe.get(i).getHp();
				faible=i;
			}			
		}
		Heros heros=(Heros) herosListe.get(faible);
		return heros;	
	}
	
}
