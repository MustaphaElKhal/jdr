package fr.aston.jdr.modele;

public class Heros extends Personnage {
	
private String classe;

public Heros() {
	super();
	// TODO Auto-generated constructor stub
}

@Override
public String toString() {
	return super.getNom() +" un.e " + classe + " avec les paramètres suivants : ";
}


public String getClasse() {
	return classe;
}
public void setClasse(String classe) {
	this.classe = classe;
}

}
