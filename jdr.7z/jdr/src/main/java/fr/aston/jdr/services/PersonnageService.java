package fr.aston.jdr.services;

import java.util.List;
import java.util.Random;

import fr.aston.jdr.modele.Personnage;

public class PersonnageService {
	
	private int persoAdverse;
	
	public void Cibler (List <Personnage> list, Personnage p) {
		
		// Rajouter la probabilité d'avoir un coup critique
		
		persoAdverse = (int) (Math.random()* list.size());
		if (list.size() > 0) {
			p.setPersoOpposant(list.get(persoAdverse));
			this.Attaquer(list, p);
		} else {
			p.setPersoOpposant(null);
		}
	}
	
	public void Attaquer(List <Personnage> list, Personnage p) {
		
		if (p.getPersoOpposant() != null) {
								
			Random random = new Random();
			Double randomAtk = random.nextInt((int) (p.getArme().getMaxAtk() + 1 - p.getArme().getMinAtk())) 
					+ p.getArme().getMinAtk();
		 
			int resteHP = (int) (list.get(persoAdverse).getHp() - randomAtk);
			list.get(persoAdverse).setHp(resteHP);
			
			System.out.println(p.getNom() + " attaque " +list.get(persoAdverse).getNom() 
					+ " et fait " + randomAtk + " dégats. Il reste " +list.get(persoAdverse).getHp() 
					+ "PV à " +list.get(persoAdverse).getNom());
		}
		// Mettre la condition si c'est un soigneur et que son HP est faible il appelle la méthode adaptée
		// Attaquer un monstre encore vivant :-)

	}
}
