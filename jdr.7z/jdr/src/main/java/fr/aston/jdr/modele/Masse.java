package fr.aston.jdr.modele;

public class Masse extends Arme{

	public Masse(double minAtk, double maxAtk, double critChance) {
		super(minAtk, maxAtk, critChance);
		this.getMinAtk();
		// TODO Auto-generated constructor stub
	}


	@Override
	public String toString() {
		return "- attaque minimum " + getMinAtk() + "\n"+
				"- attaque maximum " + getMaxAtk() + "\n"+
				"- chance coup critique " + getCritChance() + "\n";
	}


	public Masse() {
		// TODO Auto-generated constructor stub
	}

}
