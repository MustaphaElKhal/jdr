package fr.aston.jdr.modele;

public class Monstre extends Personnage {

	public Monstre() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return super.getNom() +" avec " + getMaxHp() + " PV";
	}

}
