package fr.aston.jdr.modele;

public class Epee extends Arme{

	public Epee(double minAtk, double maxAtk, double critChance) {
		super(minAtk, maxAtk, critChance);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "- attaque minimum " + getMinAtk() + "\n"+
				"- attaque maximum " + getMaxAtk() + "\n"+
				"- chance coup critique " + getCritChance() + "\n";
	}

	public Epee() {
		// TODO Auto-generated constructor stub
	}

}
