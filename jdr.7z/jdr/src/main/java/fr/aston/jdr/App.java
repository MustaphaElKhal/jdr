package fr.aston.jdr;

import fr.aston.jdr.services.PartieService;

public class App 
{
    public static void main( String[] args )
    {
        PartieService partieService = new PartieService();
        partieService.LancerPartie();
    }
}
