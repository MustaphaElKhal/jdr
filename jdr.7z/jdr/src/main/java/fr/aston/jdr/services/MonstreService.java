package fr.aston.jdr.services;

import org.apache.commons.lang3.RandomStringUtils;

public class MonstreService {
	
	private String nomMonstre;
	
	public String RandomName() {

	    int length = 10;
	    boolean useLetters = true;
	    boolean useNumbers = false;
	    nomMonstre = RandomStringUtils.random(length, useLetters, useNumbers);
	    return nomMonstre;				
	}

}
