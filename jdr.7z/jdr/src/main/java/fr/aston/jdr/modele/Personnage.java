package fr.aston.jdr.modele;

public class Personnage {
	
	private String nom;
	private Arme arme;
	private int maxHp;
	private int hp;
	private Personnage persoOpposant;
		
	public Personnage() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Personnage [nom=" + nom + ", arme=" + arme + ", maxHp=" + maxHp + ", hp=" + hp + "]";
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public Arme getArme() {
		return arme;
	}
	public void setArme(Arme arme) {
		this.arme = arme;
	}
	public int getMaxHp() {
		return maxHp;
	}
	public void setMaxHp(int maxHp) {
		this.maxHp = maxHp;
	}
	public int getHp() {
		return hp;
	}
	public void setHp(int hp) {
		this.hp = hp;
	}
	public Personnage getPersoOpposant() {
		return persoOpposant;
	}
	public void setPersoOpposant(Personnage persoOpposant) {
		this.persoOpposant = persoOpposant;
	}

}
