package fr.aston.jdr.modele;

import java.util.ArrayList;
import java.util.List;

public class Combat {
	
	private int tourN;
	private List<String> tourl=new ArrayList<String>();
	
	public Combat() {

	}

	public int getTourN() {
		return tourN;
	}

	public void setTourN(int tourN) {
		this.tourN = tourN;
	}

	public List<String> getTourl() {
		return tourl;
	}

	public void setTourl(List<String> tourl) {
		this.tourl = tourl;
	}

	@Override
	public String toString() {
		return "Combat [tourN=" + tourN + ", tourl=" + tourl + "]";
	}
	

}
