package fr.aston.jdr.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import fr.aston.jdr.modele.Arme;
import fr.aston.jdr.modele.Combat;
import fr.aston.jdr.modele.Epee;
import fr.aston.jdr.modele.Heros;
import fr.aston.jdr.modele.Masse;
import fr.aston.jdr.modele.Monstre;
import fr.aston.jdr.modele.Partie;
import fr.aston.jdr.modele.Personnage;

public class PartieService {

	private Partie partie;

	public Partie getPartie() {
		return partie;
	}

	public void setPartie(Partie partie) {
		this.partie = partie;
	}

	public PartieService() {
		this.partie = new Partie();
	}

	private int ajoutArret;
	private String nomArme;

	Scanner sc = new Scanner(System.in);

	List<Personnage> listeHeros = new ArrayList<Personnage>();
	List<Personnage> listeMonstres = new ArrayList<Personnage>();

	public void LancerPartie() {

		System.out.println("bienvenue dans mon jeu de role voulez-vous lancer une partie ?");

		char desirDebuter = sc.next().charAt(0);

		if (desirDebuter == 'o') {
			Partie partie = new Partie();
			System.out.println("nom de votre partie ?");
			String nomPartie = sc.next();
			partie.setNom(nomPartie);

			do {

				System.out.println("choix de votre classe \n" + "1 - Archer\n" + "2 - Guerrier\n" + "3 - Soigneur\n"
						+ "4 - Assassin\n");
				int choixClasse = sc.nextInt();

				HerosService herosService = new HerosService();

				if (choixClasse > 1) {

					System.out.println("choisir votre arme\n" + "1- epee\n" + "2- masse\n");
					int choixArme = sc.nextInt();

					if (choixArme == 1) {
						nomArme = "Epee";
					} else if (choixArme == 2) {
						nomArme = "Masse";
					}

				} else {
					nomArme = "Arc";

				}
				System.out.println("Nom du heros");
				String nomHeros = sc.next();

				this.CreerHeros(nomHeros, choixClasse, nomArme);
				partie.setHeros(listeHeros);
				partie.setMonstre(listeMonstres);

				System.out.println("Que voulez-vous faire ?\n" + "1 - Ajouter un joueur\n" + "2 - Lancer la partie");
				ajoutArret = sc.nextInt();

			} while (ajoutArret != 2);
			{

				System.out.println("Votre équipe se compose de : ");

				for (int i = 0; i < partie.getHeros().size(); i++) {

					System.out.println(partie.getHeros().get(i).toString());
					System.out.println(partie.getHeros().get(i).getArme().toString());
				}

				/*
				 * System.out.println("\n L'équipe des monstres se compose de : ");
				 * 
				 * for (int i = 0; i < partie.getMonstre().size(); i++) {
				 * 
				 * System.out.println(partie.getMonstre().get(i).toString());
				 * System.out.println(partie.getMonstre().get(i).getArme().toString()); }
				 */
				
				Combat combat = new Combat();
				combat.setTourN(1);
				CombatService combatService = new CombatService();
				combatService.setCombat(combat);

				while (combat.getTourN()!=0) {
					
					partie = combatService.Combattre(partie, combat);
					combatService.setTour(partie);
				}
				
				if (partie.getHeros().isEmpty()) {
					System.out.println("\n Victoire des monstres !");
				} else {
					System.out.println("\n Victoire des héros");
				}
			}

		}
	}

	public Arme SelectArme(String arme) {

		if (arme.equals("Epee")) {
			Arme a = new Epee();
			a.setMaxAtk(12.0);
			a.setMinAtk(3.0);
			a.setCritChance(2.0);
			return a;
		} else if (arme.equals("Masse")) {
			Arme a = new Masse();
			a.setMaxAtk(16.0);
			a.setMinAtk(4.0);
			a.setCritChance(16.0);
			return a;
		} else {
			Arme a = new Arme();
			a.setMaxAtk(16.0);
			a.setMinAtk(10.0);
			a.setCritChance(4.0);
			return a;
		}

	}

	public void CreerHeros(String nomHeros, int choixClasse, String nomArme) {

		HerosService herosService = new HerosService();
		Personnage heros = new Heros();

		heros = herosService.defClasse(choixClasse);
		Arme arme = SelectArme(nomArme);
		heros.setArme(arme);
		heros.setNom(nomHeros);
		listeHeros.add(heros);

		// Je créer un monstre une fois que j'ai créer un héros
		MonstreService monstreService = new MonstreService();
		Personnage monstre = new Monstre();
		monstre.setNom(monstreService.RandomName());

		Random randomGenerator = new Random();
		int randomMaxHP = randomGenerator.nextInt(100) + 1;
		monstre.setHp(randomMaxHP);
		double randomMaxAtk = randomGenerator.nextInt(16) + 1;
		double randomMinAtk = randomGenerator.nextInt(16) + 1;
		double randomCritChance = randomGenerator.nextInt(16) + 1;

		monstre.setMaxHp(randomMaxHP);

		Arme a = new Arme();
		a.setMaxAtk(16);
		a.setMinAtk(6);
		a.setCritChance(3);
		//a.setMaxAtk(randomMaxAtk);
		//a.setMinAtk(randomMinAtk);
		//a.setCritChance(randomCritChance);
		monstre.setArme(a);
		listeMonstres.add(monstre);
	}

}
