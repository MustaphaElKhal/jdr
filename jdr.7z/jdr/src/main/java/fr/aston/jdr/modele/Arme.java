package fr.aston.jdr.modele;

public class Arme {
	
	@Override
	public String toString() {
		return "- attaque minimum " + minAtk + "\n"+
				"- attaque maximum " + maxAtk + "\n"+
				"- chance coup critique " + critChance + "\n";
	}

	public double getMinAtk() {
		return minAtk;
	}

	public void setMinAtk(double minAtk) {
		this.minAtk = minAtk;
	}

	public double getMaxAtk() {
		return maxAtk;
	}

	public void setMaxAtk(double maxAtk) {
		this.maxAtk = maxAtk;
	}

	public double getCritChance() {
		return critChance;
	}

	public void setCritChance(double critChance) {
		this.critChance = critChance;
	}

	private double  minAtk;
	private double  maxAtk;
	private double  critChance;
	
	public Arme(double minAtk, double maxAtk, double critChance) {
		super();
		this.minAtk = minAtk;
		this.maxAtk = maxAtk;
		this.critChance = critChance;
	}

	public Arme() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
